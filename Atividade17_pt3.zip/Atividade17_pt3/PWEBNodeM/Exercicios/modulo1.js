var texto = "Mensagem do módulo";
module.exports = texto;